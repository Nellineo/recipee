export const proxy = 'https://cors-anywhere.herokuapp.com/'
export const key = "72881ea236ac7b0994958e5a10c8d175";